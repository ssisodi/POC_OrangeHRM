package enums;

public enum ConfigProperties {
	URL,
	BROWSER, 
}
