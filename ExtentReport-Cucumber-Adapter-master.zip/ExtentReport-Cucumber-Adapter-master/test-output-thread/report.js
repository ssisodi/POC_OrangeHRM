$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "0609df87-dbf2-4ca7-a938-6865ad5b14a0",
    "feature": "Login to HRM Application",
    "scenario": "Verify FaceBook Icon on Login Page",
    "start": 1685041761222,
    "group": 1,
    "content": "",
    "tags": "@loginpagetest,@facebooklink,",
    "end": 1685041805899,
    "className": "failed"
  },
  {
    "id": "e34b9d18-a08e-44e9-a21b-117ea967a098",
    "feature": "Login to HRM Application",
    "scenario": "Login with valid credentials",
    "start": 1685041729238,
    "group": 1,
    "content": "",
    "tags": "@loginpagetest,@validcredentials,",
    "end": 1685041761205,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});